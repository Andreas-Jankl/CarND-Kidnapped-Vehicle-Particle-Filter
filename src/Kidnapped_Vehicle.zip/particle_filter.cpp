/*
 * particle_filter.cpp
 *
 *  Created on: Dec 12, 2016
 *      Intial Author: Tiffany Huang
 *		Altered by: Andreas Jankl
 *		Inspiriation has been found here: https://github.com/thomasantony/CarND-P08-Kidnapped-Vehicle/tree/7a8993312606ca4f7a8688ea3c6985081d0a7a62
 */
 
 #ifndef M_PI
    #define M_PI 3.14159265358979323846
#endif

#include <random>
#include <algorithm>
#include <random>
#include <iostream>
#include <tuple>
#include <numeric>

#include "particle_filter.h"

using std::normal_distribution;
using std::default_random_engine;

void ParticleFilter::init(double x, double y, double theta, double std[]) {
	// TODO: Set the number of particles. Initialize all particles to first position (based on estimates of
	//   x, y, theta and their uncertainties from GPS) and all weights to 1.
	// Add random Gaussian noise to each particle.
	// NOTE: Consult particle_filter.h for more information about this method (and others in this file).

	//create gaussian distributions
	default_random_engine gen_;
    normal_distribution<double> dist_x(x, std[0]);
    normal_distribution<double> dist_y(y, std[1]);
    normal_distribution<double> dist_theta(theta, std[2]);

    num_particles = 200;
    weights.resize(num_particles, 1.0f);

	//create initial number of particles
    for(int i=0; i<num_particles; i++)
    {
        Particle p;
        p.x = dist_x(gen_);
        p.y = dist_y(gen_);
        p.theta = dist_theta(gen_);
        p.id = i;
        p.weight = 1.0f;
        particles.push_back(p);
    }
    is_initialized = true;
}

void ParticleFilter::prediction(double delta_t, double std_pos[], double velocity, double yaw_rate) {
	// TODO: Add measurements to each particle and add random Gaussian noise.
	// NOTE: When adding noise you may find std::normal_distribution and std::default_random_engine useful.
	//  http://en.cppreference.com/w/cpp/numeric/random/normal_distribution
	//  http://www.cplusplus.com/reference/random/default_random_engine/

	//create gaussian distribuations
	default_random_engine gen_;
    normal_distribution<double> dist_x(0, std_pos[0]);
    normal_distribution<double> dist_y(0, std_pos[1]);
    normal_distribution<double> dist_yaw(0, std_pos[2]);

	//loop through all particles
    for(int i=0; i<particles.size(); i++)
    {
        //predicted state values
        double px_p, py_p;

        //predict the particle by executing the dynamic model
		//avoid division by zero for px and py parts of the state vector
        if (std::fabs(yaw_rate) > 0.01)
        {
            px_p = particles[i].x + velocity/yaw_rate * ( sin (particles[i].theta + yaw_rate*delta_t) - sin(particles[i].theta));
            py_p = particles[i].y + velocity/yaw_rate * ( cos(particles[i].theta) - cos(particles[i].theta+yaw_rate*delta_t) );
        }
        else {
            px_p = particles[i].x + velocity*delta_t*cos(particles[i].theta);
            py_p = particles[i].y + velocity*delta_t*sin(particles[i].theta);
        }

        // Yaw angle of the state vector
        double pyaw_p = particles[i].theta + yaw_rate*delta_t;

        // Add noise to all states
        px_p = px_p + dist_x(gen_);
        py_p = py_p + dist_y(gen_);
        pyaw_p = pyaw_p + dist_yaw(gen_);

		//assign the predicted particles to the original particle vector again
        particles[i].x = px_p;
        particles[i].y = py_p;
        particles[i].theta = pyaw_p;
    }

}

std::vector<LandmarkObs> ParticleFilter::dataAssociation(std::vector<LandmarkObs>& predicted, const std::vector<LandmarkObs>& observations) {
	// TODO: Find the predicted measurement that is closest to each observed measurement and assign the
	//   observed measurement to this particular landmark.
	// NOTE: this method will NOT be called by the grading code. But you will probably find it useful to
	//   implement this method and use it as a helper during the updateWeights phase.

	//declare helper variables
	double min_distance, dist, dx, dy;
    int min_i;

    //Vector of particles closest the current measurement
    std::vector<LandmarkObs> closest_measurement;

    //Run through the observations
    for(int z = 0; z < observations.size(); z++)
    {
        LandmarkObs obs_i = observations[z];

        min_distance = INFINITY;
        min_i = -1;

        //Run through the particles and find the one which is closest to the current observation
        for(int i = 0; i < predicted.size(); i++)
        {
            LandmarkObs pred_i = predicted[i];
            dx = (pred_i.x - obs_i.x);
            dy = (pred_i.y - obs_i.y);
            dist = dx*dx + dy*dy;
            if(dist < min_distance)
            {
            min_distance = dist;
            min_i = i;
            }
        }

    closest_measurement.push_back(predicted[min_i]);

    }

    //return a vector of the particles that are closest to the observations and in the same order as the observations
    return closest_measurement;

}

void ParticleFilter::updateWeights(double sensor_range, double std_landmark[],std::vector<LandmarkObs> observations, Map map_landmarks) {
	// TODO: Update the weights of each particle using a mult-variate Gaussian distribution. You can read
	//   more about this distribution here: https://en.wikipedia.org/wiki/Multivariate_normal_distribution
	// NOTE: The observations are given in the VEHICLE'S coordinate system. Your particles are located
	//   according to the MAP'S coordinate system. You will need to transform between the two systems.
	//   Keep in mind that this transformation requires both rotation AND translation (but no scaling).
	//   The following is a good resource for the theory:
	//   https://www.willamette.edu/~gorr/classes/GeneralGraphics/Transforms/transforms2d.htm
	//   and the following is a good resource for the actual equation to implement (look at equation
	//   3.33. Note that you'll need to switch the minus sign in that equation to a plus to account
	//   for the fact that the map's y-axis actually points downwards.)
	//   http://planning.cs.uiuc.edu/node99.html

    double sigma_landmark [2] = {0.3, 0.3}; // Landmark measurement uncertainty [x [m], y [m]]
    double cov_x = sigma_landmark[0]*sigma_landmark[0];
    double cov_y = sigma_landmark[1]*sigma_landmark[1];
    double normalizer_gaussian = 2.0*M_PI*sigma_landmark[0]*sigma_landmark[1];

    //loop through all particles
    for(int i=0; i < particles.size(); i++)
    {
        Particle p = particles[i];

        std::vector<LandmarkObs> potential_predicted_landmarks;

        //Filter the map for the landmarks that can be seen from a single particle. This is to lower the effort in later steps
        for(int z=0; z < map_landmarks.landmark_list.size(); z++)
        {
            auto lm = map_landmarks.landmark_list[z];
            LandmarkObs lm_pred;
            lm_pred.x = lm.x_f;
            lm_pred.y = lm.y_f;
            lm_pred.id = lm.id_i;
            double dx = lm_pred.x - p.x;
            double dy = lm_pred.y - p.y;

            // Add the landmark only if the landmark is in range
            if(dx*dx + dy*dy <= sensor_range*sensor_range)
                potential_predicted_landmarks.push_back(lm_pred);
        }

        std::vector<LandmarkObs> transformed_obs;
        double total_prob = 1.0f;

        // Transform the coordinates from the observations from the coordinate system of the current particle in which the observations are given to global
        for(int u=0; u<observations.size(); u++)
        {
            LandmarkObs observation_temp;

            observation_temp.x = p.x + observations[u].x * cos(p.theta) - observations[u].y * sin(p.theta);
            observation_temp.y = p.y + observations[u].x * sin(p.theta) + observations[u].y * cos(p.theta);
            observation_temp.id= observations[u].id;

            transformed_obs.push_back(std::move(observation_temp));
        }

        std::vector<LandmarkObs> associated_landmarks;
        associated_landmarks = dataAssociation(potential_predicted_landmarks, transformed_obs);

        //Update the weight of the particle by calculating the probability from a Gaussian distribution for each observation and associated measurement
        for(unsigned l=0; l < transformed_obs.size(); l++)
        {

            double dx = (transformed_obs[l].x - associated_landmarks[l].x);
            double dy = (transformed_obs[l].y - associated_landmarks[l].y);
            double temp_prob = exp(-(dx*dx/(2*cov_x) + dy*dy/(2*cov_y)))/normalizer_gaussian;

            total_prob *= temp_prob;
        }
        particles[i].weight = total_prob;
        weights[i] = total_prob;
    }
}

void ParticleFilter::resample() {
	// TODO: Resample particles with replacement with probability proportional to their weight.
	// NOTE: You may find std::discrete_distribution helpful here.
	//   http://en.cppreference.com/w/cpp/numeric/random/discrete_distribution
    
	//create a distribution based on the weights as indicated in the hints above
	default_random_engine gen_;
	std::discrete_distribution<int> d(weights.begin(), weights.end());
    std::vector<Particle> new_particles;

	//draw the same amounts of particles as before from this distribution
    for(unsigned i = 0; i < num_particles; i++)
    {
        auto ind = d(gen_);
        new_particles.push_back(std::move(particles[ind]));
    }
    particles = std::move(new_particles);
}

void ParticleFilter::write(std::string filename) {
	// You don't need to modify this file.
	std::ofstream dataFile;
	dataFile.open(filename, std::ios::app);
	for (int i = 0; i < num_particles; ++i) {
		dataFile << particles[i].x << " " << particles[i].y << " " << particles[i].theta << "\n";
	}
	dataFile.close();
}
